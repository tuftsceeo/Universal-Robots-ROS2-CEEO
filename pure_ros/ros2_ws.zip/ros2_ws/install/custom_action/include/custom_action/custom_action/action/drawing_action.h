// generated from rosidl_generator_c/resource/idl.h.em
// with input from custom_action:action/DrawingAction.idl
// generated code does not contain a copyright notice

#ifndef CUSTOM_ACTION__ACTION__DRAWING_ACTION_H_
#define CUSTOM_ACTION__ACTION__DRAWING_ACTION_H_

#include "custom_action/action/detail/drawing_action__struct.h"
#include "custom_action/action/detail/drawing_action__functions.h"
#include "custom_action/action/detail/drawing_action__type_support.h"

#endif  // CUSTOM_ACTION__ACTION__DRAWING_ACTION_H_
