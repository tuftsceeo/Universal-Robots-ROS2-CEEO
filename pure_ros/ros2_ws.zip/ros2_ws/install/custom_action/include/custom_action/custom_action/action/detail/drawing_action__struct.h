// generated from rosidl_generator_c/resource/idl__struct.h.em
// with input from custom_action:action/DrawingAction.idl
// generated code does not contain a copyright notice

#ifndef CUSTOM_ACTION__ACTION__DETAIL__DRAWING_ACTION__STRUCT_H_
#define CUSTOM_ACTION__ACTION__DETAIL__DRAWING_ACTION__STRUCT_H_

#ifdef __cplusplus
extern "C"
{
#endif

#include <stdbool.h>
#include <stddef.h>
#include <stdint.h>


// Constants defined in the message

// Include directives for member types
// Member 'coordinates'
#include "rosidl_runtime_c/string.h"

/// Struct defined in action/DrawingAction in the package custom_action.
typedef struct custom_action__action__DrawingAction_Goal
{
  rosidl_runtime_c__String coordinates;
} custom_action__action__DrawingAction_Goal;

// Struct for a sequence of custom_action__action__DrawingAction_Goal.
typedef struct custom_action__action__DrawingAction_Goal__Sequence
{
  custom_action__action__DrawingAction_Goal * data;
  /// The number of valid items in data
  size_t size;
  /// The number of allocated items in data
  size_t capacity;
} custom_action__action__DrawingAction_Goal__Sequence;


// Constants defined in the message

/// Struct defined in action/DrawingAction in the package custom_action.
typedef struct custom_action__action__DrawingAction_Result
{
  bool result;
} custom_action__action__DrawingAction_Result;

// Struct for a sequence of custom_action__action__DrawingAction_Result.
typedef struct custom_action__action__DrawingAction_Result__Sequence
{
  custom_action__action__DrawingAction_Result * data;
  /// The number of valid items in data
  size_t size;
  /// The number of allocated items in data
  size_t capacity;
} custom_action__action__DrawingAction_Result__Sequence;


// Constants defined in the message

/// Struct defined in action/DrawingAction in the package custom_action.
typedef struct custom_action__action__DrawingAction_Feedback
{
  float status;
} custom_action__action__DrawingAction_Feedback;

// Struct for a sequence of custom_action__action__DrawingAction_Feedback.
typedef struct custom_action__action__DrawingAction_Feedback__Sequence
{
  custom_action__action__DrawingAction_Feedback * data;
  /// The number of valid items in data
  size_t size;
  /// The number of allocated items in data
  size_t capacity;
} custom_action__action__DrawingAction_Feedback__Sequence;


// Constants defined in the message

// Include directives for member types
// Member 'goal_id'
#include "unique_identifier_msgs/msg/detail/uuid__struct.h"
// Member 'goal'
#include "custom_action/action/detail/drawing_action__struct.h"

/// Struct defined in action/DrawingAction in the package custom_action.
typedef struct custom_action__action__DrawingAction_SendGoal_Request
{
  unique_identifier_msgs__msg__UUID goal_id;
  custom_action__action__DrawingAction_Goal goal;
} custom_action__action__DrawingAction_SendGoal_Request;

// Struct for a sequence of custom_action__action__DrawingAction_SendGoal_Request.
typedef struct custom_action__action__DrawingAction_SendGoal_Request__Sequence
{
  custom_action__action__DrawingAction_SendGoal_Request * data;
  /// The number of valid items in data
  size_t size;
  /// The number of allocated items in data
  size_t capacity;
} custom_action__action__DrawingAction_SendGoal_Request__Sequence;


// Constants defined in the message

// Include directives for member types
// Member 'stamp'
#include "builtin_interfaces/msg/detail/time__struct.h"

/// Struct defined in action/DrawingAction in the package custom_action.
typedef struct custom_action__action__DrawingAction_SendGoal_Response
{
  bool accepted;
  builtin_interfaces__msg__Time stamp;
} custom_action__action__DrawingAction_SendGoal_Response;

// Struct for a sequence of custom_action__action__DrawingAction_SendGoal_Response.
typedef struct custom_action__action__DrawingAction_SendGoal_Response__Sequence
{
  custom_action__action__DrawingAction_SendGoal_Response * data;
  /// The number of valid items in data
  size_t size;
  /// The number of allocated items in data
  size_t capacity;
} custom_action__action__DrawingAction_SendGoal_Response__Sequence;


// Constants defined in the message

// Include directives for member types
// Member 'goal_id'
// already included above
// #include "unique_identifier_msgs/msg/detail/uuid__struct.h"

/// Struct defined in action/DrawingAction in the package custom_action.
typedef struct custom_action__action__DrawingAction_GetResult_Request
{
  unique_identifier_msgs__msg__UUID goal_id;
} custom_action__action__DrawingAction_GetResult_Request;

// Struct for a sequence of custom_action__action__DrawingAction_GetResult_Request.
typedef struct custom_action__action__DrawingAction_GetResult_Request__Sequence
{
  custom_action__action__DrawingAction_GetResult_Request * data;
  /// The number of valid items in data
  size_t size;
  /// The number of allocated items in data
  size_t capacity;
} custom_action__action__DrawingAction_GetResult_Request__Sequence;


// Constants defined in the message

// Include directives for member types
// Member 'result'
// already included above
// #include "custom_action/action/detail/drawing_action__struct.h"

/// Struct defined in action/DrawingAction in the package custom_action.
typedef struct custom_action__action__DrawingAction_GetResult_Response
{
  int8_t status;
  custom_action__action__DrawingAction_Result result;
} custom_action__action__DrawingAction_GetResult_Response;

// Struct for a sequence of custom_action__action__DrawingAction_GetResult_Response.
typedef struct custom_action__action__DrawingAction_GetResult_Response__Sequence
{
  custom_action__action__DrawingAction_GetResult_Response * data;
  /// The number of valid items in data
  size_t size;
  /// The number of allocated items in data
  size_t capacity;
} custom_action__action__DrawingAction_GetResult_Response__Sequence;


// Constants defined in the message

// Include directives for member types
// Member 'goal_id'
// already included above
// #include "unique_identifier_msgs/msg/detail/uuid__struct.h"
// Member 'feedback'
// already included above
// #include "custom_action/action/detail/drawing_action__struct.h"

/// Struct defined in action/DrawingAction in the package custom_action.
typedef struct custom_action__action__DrawingAction_FeedbackMessage
{
  unique_identifier_msgs__msg__UUID goal_id;
  custom_action__action__DrawingAction_Feedback feedback;
} custom_action__action__DrawingAction_FeedbackMessage;

// Struct for a sequence of custom_action__action__DrawingAction_FeedbackMessage.
typedef struct custom_action__action__DrawingAction_FeedbackMessage__Sequence
{
  custom_action__action__DrawingAction_FeedbackMessage * data;
  /// The number of valid items in data
  size_t size;
  /// The number of allocated items in data
  size_t capacity;
} custom_action__action__DrawingAction_FeedbackMessage__Sequence;

#ifdef __cplusplus
}
#endif

#endif  // CUSTOM_ACTION__ACTION__DETAIL__DRAWING_ACTION__STRUCT_H_
